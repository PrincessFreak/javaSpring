package com.example.unistore;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UnistoreApplicationTests {

    @Test
    void contextLoads() {
    }

}
