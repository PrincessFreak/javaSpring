package com.example.unistore.enumm;

public enum Status {
    Принят, Оформлен, Ожидание, Получен
}
